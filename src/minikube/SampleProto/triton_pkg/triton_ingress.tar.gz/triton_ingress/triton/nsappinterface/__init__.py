__import__('pkg_resources').declare_namespace("triton")

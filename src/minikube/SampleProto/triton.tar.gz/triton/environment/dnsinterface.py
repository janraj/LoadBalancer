class DNSInterface(object):
	pass

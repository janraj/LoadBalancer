import nstriton

def start_main():
	nstriton.main()

if __name__ == "__main__":
	start_main()
